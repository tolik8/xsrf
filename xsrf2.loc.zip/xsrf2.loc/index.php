<?php
$content = file_get_contents('http://xsrf1.loc/index.php');

$lines = explode(chr(13), $content);

foreach ($lines as $line) {
    if (substr(trim($line),0,26) == '<input hidden name="token"') {
        $token = substr(trim($line),34,-2);
    }
}

include 'html/index.html';